// DIAG EFS read-only: only OPEN(O_RDONLY), READ and CLOSE; fixed policy-file allowlist.
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <errno.h>
static pthread_mutex_t mu=PTHREAD_MUTEX_INITIALIZER;static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static uint8_t frame[131072],resp[4096];static size_t used,rlen;static int escaped,ready,want,subsys;static int(*sendfn)(int,unsigned char*,int);
static unsigned r16(const uint8_t*p){return p[0]|p[1]<<8;}static uint32_t r32(const uint8_t*p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}static void w32(uint8_t*p,uint32_t n){for(int i=0;i<4;i++)p[i]=n>>(8*i);}
static uint16_t crc(const uint8_t*p,size_t n){uint16_t c=0xffff;for(size_t i=0;i<n;i++){c^=p[i];for(int j=0;j<8;j++)c=(c>>1)^((c&1)?0x8408:0);}return c;}
static void packet(const uint8_t*p,size_t n){if(n<3||crc(p,n)!=0xf0b8)return;n-=2;pthread_mutex_lock(&mu);if(n>=4&&p[0]==0x4b&&p[1]==subsys&&r16(p+2)==(unsigned)want&&n<=sizeof(resp)){memcpy(resp,p,n);rlen=n;ready=1;pthread_cond_signal(&cv);}else if(n&&p[0]>=0x13&&p[0]<=0x18){printf("DIAG_ERROR_OPCODE %02x\n",p[0]);}pthread_mutex_unlock(&mu);}
static int cb(unsigned char*p,int n,void*ctx){(void)ctx;for(int i=0;i<n;i++){unsigned b=p[i];if(b==0x7e){if(used)packet(frame,used);used=0;escaped=0;}else if(b==0x7d){escaped=1;}else{if(escaped){b^=0x20;escaped=0;}if(used<sizeof(frame))frame[used++]=b;else used=0;}}return 0;}
static int request(uint8_t*p,size_t n,unsigned cmd){if(p[0]!=0x4b||p[1]!=subsys||r16(p+2)!=cmd||(cmd!=2&&cmd!=3&&cmd!=4&&cmd!=5))return -1;if(cmd==2&&((r32(p+4)!=0&&r32(p+4)!=513)||r32(p+8)))return -1;if(cmd==5&&(n<13||n>1036))return -1;pthread_mutex_lock(&mu);want=cmd;ready=0;pthread_mutex_unlock(&mu);if(sendfn(0,p,n))return -1;struct timespec end;clock_gettime(CLOCK_REALTIME,&end);end.tv_sec+=4;pthread_mutex_lock(&mu);while(!ready){int e=pthread_cond_timedwait(&cv,&mu,&end);if(e==ETIMEDOUT)break;}int ok=ready;pthread_mutex_unlock(&mu);return ok?0:-1;}


#include "neutral_original.h"
#include "neutral_candidate.h"
static const char *path="/nv/item_files/mcfg/mcfg_sel_db.xml";
static int openf(unsigned flags,uint32_t*fd){uint8_t q[256]={0x4b,19,2,0};w32(q+4,flags);strcpy((char*)q+12,path);if(request(q,13+strlen(path),2)||rlen!=12||r32(resp+8))return -1;*fd=r32(resp+4);return 0;}
static int closef(uint32_t fd){uint8_t q[8]={0x4b,19,3,0};w32(q+4,fd);return request(q,8,3)||rlen!=8||r32(resp+4)?-1:0;}
static int readf(uint8_t*out,size_t*len){uint32_t fd;if(openf(0,&fd))return -1;size_t off=0;int failed=0;while(off<8192){uint8_t q[16]={0x4b,19,4,0};w32(q+4,fd);w32(q+8,1024);w32(q+12,off);if(request(q,16,4)||rlen<20||r32(resp+4)!=fd||r32(resp+8)!=off||r32(resp+16)){failed=1;break;}unsigned n=r32(resp+12);if(n>1024||rlen!=20+n||off+n>8192){failed=1;break;}memcpy(out+off,resp+20,n);off+=n;if(n<1024)break;}if(closef(fd))failed=1;*len=off;return failed?-1:0;}
static int writef(const uint8_t*data,size_t len){uint32_t fd;if(openf(513,&fd))return -1;int failed=0;for(size_t off=0;off<len;){unsigned n=len-off>1024?1024:len-off;uint8_t q[1036]={0x4b,19,5,0};w32(q+4,fd);w32(q+8,off);memcpy(q+12,data+off,n);if(request(q,12+n,5)||rlen!=20||r32(resp+4)!=fd||r32(resp+8)!=off||r32(resp+12)!=n||r32(resp+16)){failed=1;break;}off+=n;}if(closef(fd))failed=1;return failed?-1:0;}
int main(int argc,char**argv){setbuf(stdout,NULL);if(argc!=2)return 2;int restore=!strcmp(argv[1],"--restore"),check=!strcmp(argv[1],"--check");if(!restore&&!check&&strcmp(argv[1],"--apply"))return 2;subsys=19;
void*h=dlopen("/vendor/lib64/libdiag.so",RTLD_NOW|RTLD_LOCAL);if(!h)return 1;unsigned char(*init)(unsigned char*)=dlsym(h,"Diag_LSM_Init");unsigned char(*deinit)(void)=dlsym(h,"Diag_LSM_DeInit");void(*reg)(int(*)(unsigned char*,int,void*),void*)=dlsym(h,"diag_register_callback");void(*mode)(int,char*)=dlsym(h,"diag_switch_logging");sendfn=dlsym(h,"diag_callback_send_data");if(!init||!deinit||!reg||!mode||!sendfn||!init(NULL))return 1;int proc=0;reg(cb,&proc);mode(6,NULL);usleep(300000);
int result=1;uint8_t bytes[8192];size_t len=0;if(readf(bytes,&len)){puts("READ_FAILED_NO_WRITES");goto done;}int original=len==sizeof(neutral_original)&&!memcmp(bytes,neutral_original,len),candidate=len==sizeof(neutral_candidate)&&!memcmp(bytes,neutral_candidate,len);if(!original&&!candidate){puts("UNKNOWN_CONTENT_NO_WRITES");goto done;}printf("CONTENT %s bytes=%zu\n",original?"ORIGINAL":"CANDIDATE",len);if(check){result=0;goto done;}const uint8_t*target=restore?neutral_original:neutral_candidate;size_t size=restore?sizeof(neutral_original):sizeof(neutral_candidate);if(len==size&&!memcmp(bytes,target,size)){puts("ALREADY_TARGET");result=0;goto done;}if(writef(target,size)){puts("WRITE_RESULT_UNKNOWN_STOP");goto done;}if(readf(bytes,&len)||len!=size||memcmp(bytes,target,size)){puts("READBACK_FAILED_STOP");goto done;}puts("WRITE_FULL_READBACK_VERIFIED");result=0;
done:mode(1,NULL);deinit();return result;}
