import sys, os, struct, json, re, collections
from pycrate_asn1dir import RRCNR

NAMES={1:'BCCH_BCH_Message',2:'BCCH_DL_SCH_Message',3:'DL_CCCH_Message',4:'DL_DCCH_Message',5:'PCCH_Message',6:'UL_CCCH_Message',7:'UL_CCCH1_Message',8:'UL_DCCH_Message',9:'RRCReconfiguration',10:'RRCReconfigurationComplete'}

def frames(data):
    for raw in data.split(b'\x7e')[:-1]:
        out=bytearray(); escape=False
        for b in raw:
            if escape:out.append(b^32);escape=False
            elif b==125:escape=True
            else:out.append(b)
        crc=65535
        for b in out:
            crc^=b
            for _ in range(8):crc=(crc>>1)^(0x8408 if crc&1 else 0)
        if crc==0xf0b8:yield bytes(out[:-2])

def decode(source,dest):
    os.makedirs(dest,exist_ok=True);rows=[];logs=collections.Counter();bad=0
    for index,f in enumerate(frames(open(source,'rb').read())):
        if f[:1]==b'\x98':
            if len(f)<8:continue
            f=f[8:]
        if len(f)<20 or f[0]!=16:continue
        code=struct.unpack_from('<H',f,6)[0];logs['%04X'%code]+=1
        if code!=0xb821:continue
        b=f[16:];version=struct.unpack_from('<I',b)[0]
        row={'index':index,'version':version,'label':'Unsupported NR packet version %d'%version,'detail':'Raw packet retained in capture.'}
        if version!=17:rows.append(row);continue
        try:
            h=struct.unpack('<BBBH Q I3sBIH',b[4:31]);pid=h[-3];p=b[31:]
            row.update(pci=h[3],arfcn=h[5],pdu_id=pid)
            if len(p)!=h[-1]:raise ValueError('PDU length mismatch')
            if pid not in NAMES:
                row['label']='Unsupported NR PDU %d'%pid;rows.append(row);continue
            obj=getattr(RRCNR.NR_RRC_Definitions,NAMES[pid]);obj.from_uper(p);text=obj.to_asn1()
            label=re.search(r'message\s+(?:c1\s*:\s*)?([\w-]+)',text)
            row['label']=label.group(1) if label else NAMES[pid]
            details=[text]
            if row['label']=='ueCapabilityInformation':
                val=obj.get_val()
                def walk(v):
                    if isinstance(v,dict):
                        if v.get('rat-Type')=='nr' and isinstance(v.get('ue-CapabilityRAT-Container'),bytes):
                            cap=RRCNR.NR_RRC_Definitions.UE_NR_Capability
                            cap.from_uper(v['ue-CapabilityRAT-Container']);details.append('\nDecoded UE-NR-Capability\n'+cap.to_asn1())
                        for x in v.values():walk(x)
                    elif isinstance(v,(tuple,list)):
                        for x in v:walk(x)
                walk(val)
            row['detail']='\n'.join(details)
            row['highlights']=re.findall(r'(?:maxRank\s+\d+|nrofSRS-Ports\s+\w+|maxNumberMIMO-LayersCB-PUSCH\s+\w+|supportedBandwidthUL\s+[^,\n]+)',row['detail'])
        except Exception as exc:
            row['label']='Decode error';row['detail']=str(exc);bad+=1
        rows.append(row)
    result={'messages':rows,'logs':dict(logs),'errors':bad,'note':'NR RRC v17 only. Unsupported packets retained raw. No PHY rank/throughput decoder in this version.'}
    with open(os.path.join(dest,'decoded.json'),'w') as f:json.dump(result,f)
    with open(os.path.join(dest,'decoded.txt'),'w') as f:
        f.write(result['note']+'\n')
        for row in rows:f.write('\n=== %s | ARFCN %s PCI %s ===\n%s\n'%(row['label'],row.get('arfcn','?'),row.get('pci','?'),row['detail']))
    print('Decoded %d NR RRC messages; %d errors'%(len(rows),bad))

if __name__=='__main__':decode(sys.argv[1],sys.argv[2])
