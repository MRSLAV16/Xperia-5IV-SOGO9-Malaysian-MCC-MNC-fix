#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/file.h>
#include <fcntl.h>
static FILE *out; static pthread_mutex_t mu=PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cv=PTHREAD_COND_INITIALIZER;
static unsigned char frame[131072],response[4096];static size_t used,rlen,bytes;
static int escaped,ready,want;static volatile sig_atomic_t stop;
static int (*sendfn)(int,unsigned char*,int);
static unsigned get32(const unsigned char*p){return p[0]|p[1]<<8|p[2]<<16|(unsigned)p[3]<<24;}
static void put32(unsigned char*p,unsigned v){for(int i=0;i<4;i++)p[i]=v>>(8*i);}
static void end(int x){(void)x;stop=1;}
static void packet(void){
 unsigned short crc=0xffff;for(size_t i=0;i<used;i++){crc^=frame[i];for(int j=0;j<8;j++)crc=(crc>>1)^((crc&1)?0x8408:0);}
 if(used<14||crc!=0xf0b8)return;
 if(frame[0]==0x73&&get32(frame+4)==(unsigned)want&&used-2<=sizeof(response)){
  memcpy(response,frame,used-2);rlen=used-2;ready=1;pthread_cond_signal(&cv);
 }
}
static int cb(unsigned char*p,int n,void*c){(void)c;if(!p||n<=0)return 0;
 pthread_mutex_lock(&mu);
 if(bytes<64*1024*1024){fwrite(p,1,n,out);fflush(out);bytes+=n;}else stop=1;
 for(int i=0;i<n;i++){unsigned b=p[i];if(b==126){if(used)packet();used=0;escaped=0;}else if(b==125)escaped=1;else{if(escaped){b^=32;escaped=0;}if(used<sizeof(frame))frame[used++]=b;else used=0;}}
 pthread_mutex_unlock(&mu);return 0;
}
static int request(unsigned char*p,size_t n,int op){
 pthread_mutex_lock(&mu);want=op;ready=0;pthread_mutex_unlock(&mu);
 if(sendfn(0,p,(int)n))return -1;
 struct timespec until;clock_gettime(CLOCK_REALTIME,&until);until.tv_sec+=4;
 pthread_mutex_lock(&mu);while(!ready)if(pthread_cond_timedwait(&cv,&mu,&until))break;
 int ok=ready&&rlen>=12&&get32(response+8)==0;pthread_mutex_unlock(&mu);return ok?0:-1;
}
int main(int argc,char**argv){
 setbuf(stdout,NULL);if(argc!=3)return 2;
 char lockpath[4096];if(snprintf(lockpath,sizeof(lockpath),"%s.lock",argv[2])>=(int)sizeof(lockpath))return 2;
 int lockfd=open(lockpath,O_CREAT|O_RDWR,0600);if(lockfd<0||flock(lockfd,LOCK_EX|LOCK_NB)){puts("ERROR: capture already running");return 2;}
 signal(SIGTERM,end);signal(SIGINT,end);
 void*h=dlopen("/vendor/lib64/libdiag.so",RTLD_NOW);if(!h){printf("ERROR: libdiag load failed: %s\n",dlerror());return 3;}
 unsigned char(*init)(unsigned char*)=dlsym(h,"Diag_LSM_Init");
 unsigned char(*deinit)(void)=dlsym(h,"Diag_LSM_DeInit");
 void(*reg)(int(*)(unsigned char*,int,void*),void*)=dlsym(h,"diag_register_callback");
 void(*mode)(int,char*)=dlsym(h,"diag_switch_logging");sendfn=dlsym(h,"diag_callback_send_data");
 if(!init||!deinit||!reg||!mode||!sendfn)return 4;
 out=fopen(argv[1],"wb");if(!out)return 5;chmod(argv[1],0644);
 if(!init(NULL)){fclose(out);return 6;}int proc=0;reg(cb,&proc);mode(6,NULL);
 unsigned char query[12]={0x73,0,0,0,4,0,0,0,11,0,0,0};
 unsigned char saved[4096]={0},temp[4096]={0};size_t len=0;int changed=0,result=1;
 char backup[4096];if(snprintf(backup,sizeof(backup),"%s.mask",argv[2])>=(int)sizeof(backup)){puts("ERROR: path too long");goto finish;}
 unsigned count=0;size_t masklen=0;
 FILE *previous=fopen(backup,"rb");
 if(previous){len=fread(saved,1,sizeof(saved),previous);fclose(previous);
  if(len<17||saved[0]!=0x73||get32(saved+4)!=3||get32(saved+8)!=11||len!=16+(get32(saved+12)+7)/8){puts("ERROR: invalid recovery snapshot");goto finish;}
  if(request(saved,len,3)){puts("ERROR: previous logging snapshot could not be restored");goto finish;}
  if(request(query,sizeof(query),4)||rlen!=len+4||memcmp(response+20,saved+16,len-16)){puts("ERROR: recovery readback failed");goto finish;}
  unlink(backup);puts("Previous interrupted capture: logging restored");
 }
 if(request(query,sizeof(query),4)||rlen<20||get32(response+12)!=11){puts("ERROR: Cannot read log mask. Close Cellular-Pro, NSG and band menu.");goto finish;}
 count=get32(response+16);masklen=(count+7)/8;
 if(count<=0x826||masklen>sizeof(saved)-16||rlen!=20+masklen){puts("ERROR: Unsupported mask layout");goto finish;}
 saved[0]=0x73;put32(saved+4,3);put32(saved+8,11);put32(saved+12,count);memcpy(saved+16,response+20,masklen);len=16+masklen;memcpy(temp,saved,len);
 int logs[]={0x821,0x825,0x826};for(int i=0;i<3;i++)temp[16+logs[i]/8]|=1u<<(logs[i]%8);
 FILE *snapshot=fopen(backup,"wb");if(!snapshot){puts("ERROR: cannot save recovery mask");goto finish;}
 int wrote=fwrite(saved,1,len,snapshot)==len;fflush(snapshot);fsync(fileno(snapshot));fclose(snapshot);if(!wrote){puts("ERROR: incomplete recovery mask");goto finish;}
 changed=1;if(request(temp,len,3)){puts("ERROR: Log enable was not acknowledged");goto finish;}
 puts("CAPTURE READY: 60 seconds. Reconnect radio or run an upload now.");
 for(int i=0;i<600&&!stop&&access(argv[2],F_OK);i++)usleep(100000);
 result=0;
finish:
 if(changed){int restored=request(saved,len,3)==0;
  if(restored&&request(query,sizeof(query),4)==0)restored=rlen==20+masklen&&get32(response+12)==11&&get32(response+16)==count&&!memcmp(response+20,saved+16,masklen);else restored=0;
  puts(restored?"RESTORE VERIFIED: original logging mask":"RESTORE FAILED: keep root active and start another capture to recover");if(!restored)result=7;else unlink(backup);
 }
 mode(1,NULL);printf("DIAG closed: %u; bytes: %zu\n",deinit(),bytes);fclose(out);return result;
}
