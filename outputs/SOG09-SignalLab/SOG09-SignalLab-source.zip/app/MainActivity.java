package dev.sog09.signallab;
import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import android.content.*;import android.graphics.Color;
import org.json.*;import java.io.*;import java.util.*;import java.util.zip.*;
public class MainActivity extends Activity {
 TextView status;LinearLayout list;Button start,stop;volatile boolean busy;File home,session;String libs;Handler handler=new Handler();
 void update(String s){android.util.Log.i("SignalLab",s);runOnUiThread(()->status.setText(s));}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);home=getFilesDir();libs=getApplicationInfo().nativeLibraryDir;
  LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setPadding(22,24,22,12);outer.setBackgroundColor(Color.rgb(15,21,29));
  TextView title=new TextView(this);title.setText("SOG09 Signal Lab");title.setTextSize(26);outer.addView(title);
  TextView desc=new TextView(this);desc.setText("Rooted Xperia 5 IV • NR RRC decoding\nClose Cellular-Pro, NSG and band menu first.\nNo EFS writes. Capture restores the prior log mask.");outer.addView(desc);
  status=new TextView(this);status.setText("Preparing offline decoder…");status.setPadding(0,18,0,18);outer.addView(status);
  LinearLayout buttons=new LinearLayout(this);start=new Button(this);start.setText("Capture 60 seconds");start.setEnabled(false);buttons.addView(start);stop=new Button(this);stop.setText("Stop");stop.setEnabled(false);buttons.addView(stop);outer.addView(buttons);
  Button replay=new Button(this);replay.setText("Decode bundled test capture");outer.addView(replay);
  Button export=new Button(this);export.setText("Save latest capture to Downloads");outer.addView(export);
  ScrollView scroll=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(outer);
  start.setOnClickListener(v->begin(false));replay.setOnClickListener(v->begin(true));stop.setOnClickListener(v->stopCapture());export.setOnClickListener(v->export());
  new Thread(()->{try{prepare();update("Ready • "+Build.MODEL+"\nDecoder runs locally. Root is requested only for capture.");runOnUiThread(()->start.setEnabled("SOG09".equals(Build.MODEL)));if("replay".equals(getIntent().getStringExtra("mode")))runOnUiThread(()->begin(true));}catch(Exception e){update("Setup failed: "+e);}}).start();
 }
 void copy(InputStream in,OutputStream out)throws Exception{byte[] buf=new byte[65536];int n;while((n=in.read(buf))>0)out.write(buf,0,n);}
 void asset(String name,File dest)throws Exception{try(InputStream in=getAssets().open(name);OutputStream out=new FileOutputStream(dest)){copy(in,out);}}
 void prepare()throws Exception{
  File runtime=new File(home,"runtime");if(!new File(runtime,"complete-v2").exists()){
   runtime.mkdirs();try(ZipInputStream z=new ZipInputStream(getAssets().open("runtime.zip"))){ZipEntry e;while((e=z.getNextEntry())!=null){File f=new File(runtime,e.getName());if(!f.getCanonicalPath().startsWith(runtime.getCanonicalPath()+"/"))throw new IOException("Invalid runtime path");if(e.isDirectory())f.mkdirs();else{f.getParentFile().mkdirs();try(OutputStream out=new FileOutputStream(f)){copy(z,out);}}}}
   new File(runtime,"complete-v2").createNewFile();
  }asset("decode.py",new File(home,"decode.py"));
 }
 String quote(String s){return "'"+s.replace("'","'\\''")+"'";}
 String run(List<String> cmd,boolean python)throws Exception{
  ProcessBuilder pb=new ProcessBuilder(cmd).redirectErrorStream(true);
  if(python){pb.environment().put("PYTHONHOME",new File(home,"runtime").getPath());pb.environment().put("LD_LIBRARY_PATH",libs);pb.environment().put("PYTHONNOUSERSITE","1");}
  java.lang.Process p=pb.start();StringBuilder all=new StringBuilder();try(BufferedReader r=new BufferedReader(new InputStreamReader(p.getInputStream()))){String line;while((line=r.readLine())!=null){all.append(line).append('\n');if(!python)update(line);}}
  int rc=p.waitFor();if(rc!=0)throw new IOException("Exit "+rc+": "+all);return all.toString();
 }
 void begin(boolean test){if(busy)return;busy=true;start.setEnabled(false);stop.setEnabled(!test);list.removeAllViews();
  new Thread(()->{try{
   session=new File(home,"sessions/"+System.currentTimeMillis());session.mkdirs();File raw=new File(session,"capture.hdlc");
   if(test){asset("test.hdlc",raw);update("Decoding bundled capture…");}
   else{File flag=new File(home,"stop");flag.delete();update("Requesting root. Keep this app open…");
    String log=run(Arrays.asList("/system/bin/su","-c","LD_LIBRARY_PATH=/vendor/lib64:/system/lib64 "+quote(libs+"/libcapture.so")+" "+quote(raw.getPath())+" "+quote(flag.getPath())),false);
    try(FileWriter w=new FileWriter(new File(session,"capture-status.txt"))){w.write(log);}
    update("Capture closed; decoding…");
   }
   String result=run(Arrays.asList(libs+"/libpythonrunner.so",new File(home,"decode.py").getPath(),raw.getPath(),session.getPath()),true);showResults(result);
  }catch(Exception e){update("Stopped: "+e.getMessage());}finally{busy=false;runOnUiThread(()->{start.setEnabled("SOG09".equals(Build.MODEL));stop.setEnabled(false);});}}).start();
 }
 void stopCapture(){try{new File(home,"stop").createNewFile();update("Stopping and restoring diagnostic mask…");}catch(Exception e){update(e.toString());}}
 void showResults(String summary)throws Exception{
  String text=new String(java.nio.file.Files.readAllBytes(new File(session,"decoded.json").toPath()),"UTF-8");JSONObject result=new JSONObject(text);JSONArray rows=result.getJSONArray("messages");
  runOnUiThread(()->{status.setText(summary+"\n"+result.optString("note"));for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);Button b=new Button(this);b.setAllCaps(false);b.setText(row.optString("label")+"\nARFCN "+row.optString("arfcn","?")+" • PCI "+row.optString("pci","?")+"\n"+row.optJSONArray("highlights"));b.setOnClickListener(v->{TextView detail=new TextView(this);detail.setTextIsSelectable(true);detail.setText(row.optString("detail"));detail.setTextSize(12);detail.setPadding(20,12,20,12);ScrollView sv=new ScrollView(this);sv.addView(detail);new AlertDialog.Builder(this).setTitle(row.optString("label")).setView(sv).setPositiveButton("Close",null).show();});list.addView(b);}});
 }
 void export(){if(session==null||busy){update("Finish a capture first.");return;}Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.setType("application/zip");intent.putExtra(Intent.EXTRA_TITLE,"SOG09-signal-"+session.getName()+".zip");intent.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(intent,12);}
 protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==12&&result==RESULT_OK&&data!=null){try(ZipOutputStream z=new ZipOutputStream(getContentResolver().openOutputStream(data.getData()))){for(File f:session.listFiles()){if(!f.isFile())continue;z.putNextEntry(new ZipEntry(f.getName()));try(InputStream in=new FileInputStream(f)){copy(in,z);}z.closeEntry();}update("Saved capture and decoded messages.");}catch(Exception e){update(e.toString());}}}
 protected void onDestroy(){if(busy)stopCapture();super.onDestroy();}
}
