from pathlib import Path
import subprocess,os,zipfile
r=Path(__file__).resolve().parent/'app';sdk=Path(os.environ['LOCALAPPDATA'])/'Android/Sdk';bt=sdk/'build-tools/35.0.0';clang=sdk/'ndk/28.2.13676358/toolchains/llvm/prebuilt/windows-x86_64/bin/clang.exe';jar=sdk/'platforms/android-35/android.jar'
os.environ['TMP']=str(r);os.environ['TEMP']=str(r)
def run(args):subprocess.run([str(a) for a in args],check=True)
base=[clang,'--target=aarch64-linux-android28','-O2','-fPIE','-pie']
run(base+['-Wall','-Wextra','-Werror',r/'capture.c','-o',r/'lib/arm64-v8a/libcapture.so','-ldl'])
run(base+['-I'+str(r/'include/python3.10'),r/'pythonrunner.c','-L'+str(r/'lib/arm64-v8a'),'-lpython3.10','-Wl,-rpath,$ORIGIN','-o',r/'lib/arm64-v8a/libpythonrunner.so'])
run(['javac','--release','8','-classpath',jar,'-d',r/'classes',r/'MainActivity.java'])
run([bt/'d8.bat','--min-api','28','--lib',jar,'--output',r/'dex',*list((r/'classes').rglob('*.class'))])
run([bt/'aapt.exe','package','-f','-M',r/'AndroidManifest.xml','-I',jar,'-A',r/'assets','-F',r/'unsigned.apk'])
with zipfile.ZipFile(r/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 z.write(r/'dex/classes.dex','classes.dex')
 for p in (r/'lib').rglob('*.so'):z.write(p,p.relative_to(r).as_posix())
key=r.parent/'debug.keystore'
if not key.exists():run(['keytool','-genkeypair','-keystore',key,'-storepass','android','-keypass','android','-alias','signal','-keyalg','RSA','-keysize','2048','-validity','3650','-dname','CN=SOG09 Signal Lab Local Test'])
dest=Path('outputs/SOG09-SignalLab/SOG09-SignalLab-0.1.apk').resolve()
run([bt/'zipalign.exe','-f','4',r/'unsigned.apk',r/'aligned.apk'])
run([bt/'apksigner.bat','sign','--ks',key,'--ks-key-alias','signal','--ks-pass','pass:android','--out',dest,r/'aligned.apk'])
run([bt/'apksigner.bat','verify',dest]);print('BUILT',dest)
