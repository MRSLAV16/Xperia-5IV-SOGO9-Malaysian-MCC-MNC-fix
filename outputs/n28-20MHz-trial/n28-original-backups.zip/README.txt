Experimental n28 bandwidth trial

Both816-byte originals are backed up. Only byte76 changed from02 to0a in each file.
This adds the inferred20MHz n28 bit while retaining10MHz. Proprietary layout is empirically cross-checked, not officially documented.
The device accepted both writes; full readback matched; only offset76 differed.
Airplane mode was cycled and restored. Full Android reboot was avoided. Runtime capability reload and n28 registration are not yet verified.

Rollback from Windows while existing root works:
adb -s QV771XEDEE shell su -c "LD_LIBRARY_PATH=/vendor/lib64:/system/lib64 /data/local/tmp/codex_diag_n28_bw_patch --restore"

Alternatively restore the two original files with EFS Explorer to their exact paths under /nv/item_files/modem/nr5g/RRC/.
Do not replace the hardware MBN or delete the whole limit file.
After actual reload, an expected n28 base15kHz bandwidth bitmap would be50 00 (10+20MHz), but that has not yet been observed.
