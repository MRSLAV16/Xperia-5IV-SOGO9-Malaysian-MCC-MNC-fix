#!/system/bin/sh
[ "$(id -u)" = 0 ] || exit 1
[ "$(getprop ro.product.model)" = SOG09 ] || exit 2
CURRENT=$(cmd wifi get-country-code 2>/dev/null)
[ "$CURRENT" = "Wifi Country Code = TW" ] && { echo "$CURRENT"; exit 0; }
RESULT=$(cmd wifi force-country-code enabled TW 2>&1)
RC=$?
[ -n "$RESULT" ] && echo "$RESULT"
[ "$RC" = 0 ] || exit 3
CURRENT=$(cmd wifi get-country-code 2>/dev/null)
echo "$CURRENT"
[ "$CURRENT" = "Wifi Country Code = TW" ] || exit 4
