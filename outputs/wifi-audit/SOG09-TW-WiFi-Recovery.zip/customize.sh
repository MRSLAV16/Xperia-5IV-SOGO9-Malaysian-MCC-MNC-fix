#!/system/bin/sh
[ "$(getprop ro.product.model)" = SOG09 ] || abort "This package is for SOG09 only"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/apply.sh" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/action.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
ui_print "TW applies only when root module scripts run."
ui_print "With late exploit root, use this module's Action button."
