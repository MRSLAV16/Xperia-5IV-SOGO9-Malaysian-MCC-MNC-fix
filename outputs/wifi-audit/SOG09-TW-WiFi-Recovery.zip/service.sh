#!/system/bin/sh
MODDIR=${0%/*}
umask 022
COUNT=0
while [ "$(getprop sys.boot_completed)" != 1 ]; do
 COUNT=$((COUNT+1))
 [ "$COUNT" -lt 90 ] || exit 1
 sleep 2
done
COUNT=0
while [ "$COUNT" -lt 30 ]; do
 [ -f "$MODDIR/disable" ] && exit 0
 [ -f "$MODDIR/remove" ] && exit 0
 COUNT=$((COUNT+1))
 echo "Attempt $COUNT" >> "$MODDIR/last-run.txt"
 RESULT=$(sh "$MODDIR/apply.sh" 2>&1)
 RC=$?
 echo "$RESULT" >> "$MODDIR/last-run.txt"
 [ "$RC" = 0 ] && exit 0
 sleep 2
done
echo "TW apply failed; no further retries" >> "$MODDIR/last-run.txt"
exit 1
