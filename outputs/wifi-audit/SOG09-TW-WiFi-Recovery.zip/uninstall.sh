#!/system/bin/sh
cmd wifi force-country-code disabled
